﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace SETUPTEST
{
    public partial class Form1 : Form
    {
        Thread th;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "MAIN MENU";

            Directory.CreateDirectory("C:\\TEST INC");
        }

        private void EASY(object obj)
        {
            Thread.Sleep(2500);

            Application.Run(new Form2());
        }
        private void MEDIUM(object obj)
        {
            Thread.Sleep(2500);

            Application.Run(new Form3());
        }
        private void HARD(object obj)
        {
            Thread.Sleep(2500);

            Application.Run(new Form4());
        }
        private void CUSTOM(object obj)
        {
            Thread.Sleep(2500);

            Application.Run(new Form5());
        }

        private void CREDITS(object obj)
        {
            Thread.Sleep(2500);

            Application.Run(new Form6());
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
            th = new Thread(EASY);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void button2_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
            th = new Thread(MEDIUM);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void button3_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
            th = new Thread(HARD);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void button4_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
            th = new Thread(CUSTOM);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void button5_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
            th = new Thread(CREDITS);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }
    }
}
