﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace SETUPTEST
{
    public partial class Form2 : Form
    {
        Thread th2;

        int timeleft;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = "0";
            label2.Text = "YOU HAVE A MINUTE TO CLICK AS FAST AS YOU CAN";
            timeleft = 60;
            if (!File.Exists(@"C:\TEST INC\EASY.txt"))
            {
                string num = "0";
                File.AppendAllText(@"C:\TEST INC\EASY.txt", num);
            }
            string text = File.ReadAllText(@"C:\TEST INC\EASY.txt");
            label4.Text = text;
        }

        private void MENU(object obj)
        {
            Thread.Sleep(2500);

            Application.Run(new Form1());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeleft > 0)
            {
                timeleft = timeleft - 1;
            }
            else
            {
                timer1.Stop();
                MessageBox.Show("TIMES UP \nSCORE: " + label1.Text);
                button1.Enabled = false;
                button2.Enabled = true;
                if (Convert.ToInt16(label1.Text) > Convert.ToInt16(label4.Text))
                {
                    label4.Text = label1.Text;
                    string text = label4.Text;



                    File.WriteAllText(@"C:\TEST INC\EASY.txt", text);
                }

            }
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            timer1.Start();
            label1.Text = (Convert.ToInt16(label1.Text) + 1).ToString();
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
        }

        private void button2_MouseClick(object sender, MouseEventArgs e)
        {
            label1.Text = "0";
            button1.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            timeleft = 60;
        }

        private void button3_MouseClick(object sender, MouseEventArgs e)
        {
            string num = "0";
            File.WriteAllText(@"C:\TEST INC\EASY.txt", num);
            label4.Text = num;
        }

        private void button4_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
            th2 = new Thread(MENU);
            th2.SetApartmentState(ApartmentState.STA);
            th2.Start();
        }
    }
}
